import { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { mockAuth } from '../lib/mockAuth';
import type { User } from '@supabase/supabase-js';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signUp: (email: string, password: string, fullName: string) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  isDemoMode: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const isDemoModeEnabled = () => {
  const url = import.meta.env.VITE_SUPABASE_URL;
  const key = import.meta.env.VITE_SUPABASE_ANON_KEY;
  return !url || !key || url.includes('placeholder');
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [demoMode] = useState(isDemoModeEnabled());

  useEffect(() => {
    const initAuth = async () => {
      try {
        if (demoMode) {
          const demoUser = mockAuth.getCurrentUser();
          setUser(demoUser || null);
        } else {
          const { data: { session } } = await supabase.auth.getSession();
          setUser(session?.user ?? null);
        }
      } catch (err) {
        console.warn('Auth initialization:', err);
      } finally {
        setLoading(false);
      }
    };

    initAuth();

    if (!demoMode) {
      const {
        data: { subscription },
      } = supabase.auth.onAuthStateChange((_event, session) => {
        setUser(session?.user ?? null);
      });

      return () => subscription.unsubscribe();
    }
  }, [demoMode]);

  const signUp = async (email: string, password: string, fullName: string) => {
    try {
      if (demoMode) {
        const { user: demoUser } = await mockAuth.signUp(email, password);
        setUser(demoUser);
      } else {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
        });

        if (error) throw error;

        if (data.user) {
          try {
            const { error: profileError } = await supabase
              .from('profiles')
              .insert({
                id: data.user.id,
                email: data.user.email!,
                full_name: fullName,
              });

            if (profileError) throw profileError;
          } catch (err) {
            console.warn('Profile creation skipped:', err);
          }
          setUser(data.user);
        }
      }
    } catch (err) {
      throw err;
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      if (demoMode) {
        const { user: demoUser } = await mockAuth.signIn(email, password);
        setUser(demoUser);
      } else {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });

        if (error) throw error;
      }
    } catch (err) {
      throw err;
    }
  };

  const signOut = async () => {
    try {
      if (demoMode) {
        await mockAuth.signOut();
        setUser(null);
      } else {
        const { error } = await supabase.auth.signOut();
        if (error) throw error;
      }
    } catch (err) {
      throw err;
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, signUp, signIn, signOut, isDemoMode: demoMode }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
