import { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext';
import LandingPage from './components/LandingPage';
import Dashboard from './components/Dashboard';
import AuthModal from './components/AuthModal';
import ProjectWizard from './components/wizard/ProjectWizard';
import PlannerCanvas from './components/planner/PlannerCanvas';

function App() {
  const { user, loading, signIn, signUp, signOut, isDemoMode } = useAuth();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [showProjectWizard, setShowProjectWizard] = useState(false);

  const handleLogin = () => {
    setAuthMode('login');
    setShowAuthModal(true);
  };

  const handleRegister = () => {
    setAuthMode('register');
    setShowAuthModal(true);
  };

  const handleAuthSubmit = async (
    email: string,
    password: string,
    fullName?: string
  ) => {
    if (authMode === 'login') {
      await signIn(email, password);
    } else {
      await signUp(email, password, fullName || '');
    }
    setShowAuthModal(false);
  };

  const handleNewProject = () => {
    setShowProjectWizard(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-slate-600">Cargando...</p>
        </div>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/"
          element={
            user ? (
              <Navigate to="/dashboard" replace />
            ) : (
              <LandingPage onLogin={handleLogin} onRegister={handleRegister} />
            )
          }
        />
        <Route
          path="/dashboard"
          element={
            user ? (
              <Dashboard
                userEmail={user.email || 'Usuario'}
                onLogout={signOut}
                onNewProject={handleNewProject}
                isDemoMode={isDemoMode}
              />
            ) : (
              <Navigate to="/" replace />
            )
          }
        />
        <Route
          path="/taller"
          element={
            user ? <PlannerCanvas /> : <Navigate to="/" replace />
          }
        />
      </Routes>

      {showAuthModal && (
        <AuthModal
          mode={authMode}
          onClose={() => setShowAuthModal(false)}
          onSubmit={handleAuthSubmit}
        />
      )}

      {showProjectWizard && (
        <ProjectWizard
          onClose={() => setShowProjectWizard(false)}
          onSaveProject={(data) => {
            console.log('Project saved:', data);
          }}
        />
      )}
    </BrowserRouter>
  );
}

export default App;
