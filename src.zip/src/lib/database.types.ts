export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          email: string
          full_name: string | null
          company_name: string | null
          phone: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          full_name?: string | null
          company_name?: string | null
          phone?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          full_name?: string | null
          company_name?: string | null
          phone?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      projects: {
        Row: {
          id: string
          user_id: string
          client_name: string
          client_phone: string | null
          client_address: string | null
          project_type: 'certificacion' | 'presupuesto'
          property_type: 'vivienda' | 'local'
          voltage_type: '220V' | '380V'
          surface_area: number
          electrification_grade: 'minimo' | 'medio' | 'elevado' | null
          minimum_points: number
          status: 'borrador' | 'en_ejecucion' | 'finalizado'
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          client_name: string
          client_phone?: string | null
          client_address?: string | null
          project_type: 'certificacion' | 'presupuesto'
          property_type: 'vivienda' | 'local'
          voltage_type: '220V' | '380V'
          surface_area: number
          electrification_grade?: 'minimo' | 'medio' | 'elevado' | null
          minimum_points?: number
          status?: 'borrador' | 'en_ejecucion' | 'finalizado'
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          client_name?: string
          client_phone?: string | null
          client_address?: string | null
          project_type?: 'certificacion' | 'presupuesto'
          property_type?: 'vivienda' | 'local'
          voltage_type?: '220V' | '380V'
          surface_area?: number
          electrification_grade?: 'minimo' | 'medio' | 'elevado' | null
          minimum_points?: number
          status?: 'borrador' | 'en_ejecucion' | 'finalizado'
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}
