export interface ProjectConfig {
  clientName: string;
  clientPhone: string;
  destination: 'vivienda' | 'local';
  voltage: '220V' | '380V';
  projectType: 'nueva' | 'existente';
  surfaceArea: number;
  workType: 'certification_only' | 'budget_certification' | 'private_job';
}

export interface EnvironmentData {
  id: string;
  name: string;
  surface: number;
}

export interface EnvironmentCalculation extends EnvironmentData {
  lights: number;
  regularOutlets: number;
  specialOutlets: number;
}

export interface ProjectCalculation {
  grade: 'minimo' | 'medio' | 'elevado' | 'superior';
  minCircuits: number;
  actualCircuits: number;
  totalBocas: number;
  totalPoints: number;
  iluminationPower: number;
  socketsPower: number;
  specialPower: number;
  demandPower: number;
  simultaneityCoefficient: number;
  finalDemand: number;
  voltage: number;
  current: number;
  suggestedCable: string;
  suggestedBreaker: string;
  suggestedDifferential: string; // --- NUEVO CAMPO ---
}

// --- REGLAS FIJAS (LÓGICA AEA 770) ---

export function calculateElectrificationGrade(
  destination: 'vivienda' | 'local',
  surface: number
): 'minimo' | 'medio' | 'elevado' | 'superior' {
  if (destination === 'local') return 'elevado';
  if (surface < 60) return 'minimo';
  if (surface <= 130) return 'medio';
  if (surface <= 200) return 'elevado';
  return 'superior';
}

export function getMinimumCircuits(
  grade: 'minimo' | 'medio' | 'elevado' | 'superior'
): number {
  const circuits = { minimo: 2, medio: 3, elevado: 5, superior: 6 };
  return circuits[grade];
}

export function getSuggestedEnvironments(
  destination: 'vivienda' | 'local'
): EnvironmentData[] {
  if (destination === 'vivienda') {
    return [
      { id: '1', name: 'Cocina', surface: 0 },
      { id: '2', name: 'Sala / Comedor', surface: 0 },
      { id: '3', name: 'Dormitorio 1', surface: 0 },
      { id: '4', name: 'Baño', surface: 0 },
    ];
  }
  return [
    { id: '1', name: 'Salón Principal', surface: 0 },
    { id: '2', name: 'Baño / Servicio', surface: 0 },
  ];
}

// --- CÁLCULO DE BOCAS (TABLA 770.7.III) ---
export function calculateEnvironmentBocas(
  environment: EnvironmentData
): { lights: number; regularOutlets: number; specialOutlets: number } {
  
  const name = environment.name.toLowerCase().trim();
  const surface = Number(environment.surface) || 0; 

  if (name.match(/sala|estar|comedor|escritorio|estudio|living/)) {
    const lights = Math.max(1, Math.ceil(surface / 18));
    const outlets = Math.max(1, Math.ceil(surface / 6));
    return { lights, regularOutlets: outlets, specialOutlets: 0 };
  }
  if (name.match(/dormitorio|habitacion/)) {
    if (surface < 10) return { lights: 1, regularOutlets: 2, specialOutlets: 0 };
    if (surface <= 36) return { lights: 1, regularOutlets: 3, specialOutlets: 0 };
    return { lights: 2, regularOutlets: 4, specialOutlets: 0 };
  }
  if (name.includes('cocina')) {
    return { lights: 2, regularOutlets: 3, specialOutlets: 0 };
  }
  if (name.match(/baño|toilette|acero/)) {
    return { lights: 1, regularOutlets: 1, specialOutlets: 0 };
  }
  if (name.match(/vestibulo|hall|zaguan|recepcion/)) {
    return { lights: 1, regularOutlets: 1, specialOutlets: 0 };
  }
  if (name.match(/pasillo|circulacion|corredor/)) {
    const lights = Math.max(1, Math.ceil(surface / 5));
    return { lights, regularOutlets: 1, specialOutlets: 0 };
  }
  if (name.includes('lavadero')) {
    return { lights: 1, regularOutlets: 2, specialOutlets: 0 };
  }
  if (name.match(/balcon|galeria|atrio|terraza/)) {
    return { lights: 1, regularOutlets: 1, specialOutlets: 0 };
  }
  if (name.match(/garaje|cochera|estacionamiento/)) {
    return { lights: 1, regularOutlets: 1, specialOutlets: 0 };
  }
  if (name.includes('vestidor')) {
    const outlets = surface > 2 ? 1 : 0;
    return { lights: 1, regularOutlets: outlets, specialOutlets: 0 };
  }
  return { lights: 0, regularOutlets: 0, specialOutlets: 0 };
}

// --- CÁLCULO FINAL ---
export function calculateProjectDemand(
  environments: EnvironmentCalculation[],
  grade: 'minimo' | 'medio' | 'elevado' | 'superior',
  voltage: '220V' | '380V'
): ProjectCalculation {
  
  const minCircuitsByGrade = getMinimumCircuits(grade);

  let totalLights = 0;
  let totalOutlets = 0;
  let totalSpecial = 0;

  environments.forEach((env) => {
    totalLights += Number(env.lights) || 0;
    totalOutlets += Number(env.regularOutlets) || 0;
    totalSpecial += Number(env.specialOutlets) || 0;
  });

  const totalBocas = totalLights + totalOutlets + totalSpecial;
  const totalPoints = totalBocas;

  const iluminationPower = Math.ceil((totalLights * 60) * 0.66);
  const estimatedTugCircuits = Math.max(1, Math.ceil(totalOutlets / 15));
  const socketsPower = estimatedTugCircuits * 2200;
  const specialPower = totalSpecial * 3300;

  let demandPower = iluminationPower + socketsPower + specialPower;

  const estimatedTotalCircuits = 1 + estimatedTugCircuits + totalSpecial;
  const actualCircuits = Math.max(minCircuitsByGrade, estimatedTotalCircuits);

  let simultaneityCoefficient = 1.0;
  if (actualCircuits >= 5 && actualCircuits < 6) simultaneityCoefficient = 0.8;
  if (actualCircuits >= 6) simultaneityCoefficient = 0.7;

  const finalDemand = Math.ceil(demandPower * simultaneityCoefficient);

  const voltageValue = voltage === '220V' ? 220 : 380;
  let current = 0;
  
  if (voltage === '220V') {
    current = finalDemand / 220;
  } else {
    current = finalDemand / (380 * 1.732);
  }

  // Obtenemos SUGERENCIAS (Cable, Térmica y Diferencial)
  const { cable, breaker, differential } = suggestCableAndBreaker(current);

  return {
    grade,
    minCircuits: minCircuitsByGrade,
    actualCircuits,
    totalBocas,
    totalPoints,
    iluminationPower,
    socketsPower,
    specialPower,
    demandPower,
    simultaneityCoefficient,
    finalDemand,
    voltage: voltageValue,
    current,
    suggestedCable: cable,
    suggestedBreaker: breaker,
    suggestedDifferential: differential, // Agregado
  };
}

export function suggestCableAndBreaker(
  current: number
): { cable: string; breaker: string; differential: string } {
  
  let cable = '2.5mm²';
  let breaker = '16A';
  let differential = '25A / 30mA';

  // Lógica de Cable y Térmica
  if (current <= 16) {
     cable = '2.5mm²'; breaker = '16A';
  } else if (current <= 20) {
     cable = '4mm²'; breaker = '20A';
  } else if (current <= 25) {
     cable = '4mm²'; breaker = '25A';
  } else if (current <= 32) {
     cable = '6mm²'; breaker = '32A';
  } else if (current <= 40) {
     cable = '10mm²'; breaker = '40A';
  } else if (current <= 50) {
     cable = '10mm²'; breaker = '50A';
  } else if (current <= 63) {
     cable = '16mm²'; breaker = '63A';
  } else {
     cable = '25mm² +'; breaker = '80A+';
  }

  // Lógica del Diferencial (Debe ser >= que la térmica)
  // El estándar comercial es 40A para casi todo, y 63A para potencias altas.
  // 25A existe pero se usa poco, preferimos sugerir 40A por robustez.
  if (current <= 40) {
      differential = '40A / 30mA';
  } else {
      differential = '63A / 30mA';
  }

  return { cable, breaker, differential };
}

export const ENVIRONMENT_RULES = {
    sala: {}, cocina: {}, dormitorio: {}, bano: {}, lavadero: {}, pasillo: {}, 
    vestibulo: {}, balcon: {}, garaje: {}, vestidor: {}
};