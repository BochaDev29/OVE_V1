import React from 'react';
import { Check, AlertTriangle, FileText, Download, Zap, CheckCircle2, ShieldCheck } from 'lucide-react';
import {
  ProjectConfig,
  EnvironmentCalculation,
  ProjectCalculation,
} from '../../lib/electrical-rules';

interface Step3Props {
  config: ProjectConfig;
  environments: EnvironmentCalculation[];
  calculation: ProjectCalculation;
  onDownloadMemoria: () => void;
  onDownloadMateriales: () => void;
  onSaveProject: () => void;
  onBack: () => void;
}

export default function ProjectWizardStep3({
  config,
  environments,
  calculation,
  onDownloadMemoria,
  onDownloadMateriales,
  onSaveProject,
  onBack,
}: Step3Props) {
  const {
    grade,
    minCircuits,
    actualCircuits,
    totalBocas,
    iluminationPower,
    socketsPower,
    specialPower,
    finalDemand,
    voltage,
    current,
    suggestedCable,
    suggestedBreaker,
    suggestedDifferential, // <-- Nuevo dato
  } = calculation;

  return (
    <div className="space-y-6">
      {/* --- RESUMEN PRINCIPAL --- */}
      <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 flex flex-col sm:flex-row justify-between items-center gap-4">
        <div className="text-center sm:text-left">
          <p className="text-sm text-blue-600 uppercase tracking-wider font-semibold">Grado de Electrificación</p>
          <p className="text-2xl font-black text-blue-900 uppercase">{grade}</p>
          <p className="text-xs text-blue-500 mt-1">
            {config.destination === 'vivienda' ? 'Vivienda' : 'Local'} - {config.surfaceArea} m²
          </p>
        </div>
        <div className="h-10 w-px bg-blue-200 hidden sm:block"></div>
        <div className="text-center sm:text-right">
          <p className="text-sm text-blue-600 uppercase tracking-wider font-semibold">Demanda (DPMS)</p>
          <p className="text-2xl font-black text-blue-900">
            {Math.round(finalDemand)} VA
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* --- TARJETA DE CIRCUITOS --- */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2 border-b pb-2">
            <Check className="w-5 h-5 text-green-600" />
            Circuitos y Bocas
          </h4>
          <ul className="space-y-3 text-sm">
            <li className="flex justify-between items-center">
              <span className="text-slate-600">Circuitos Mínimos (Norma):</span>
              <span className="font-bold bg-slate-100 px-2 py-1 rounded text-slate-700">{minCircuits}</span>
            </li>
            <li className="flex justify-between items-center">
              <span className="text-slate-600">Circuitos Estimados (Reales):</span>
              <span className="font-bold bg-blue-50 px-2 py-1 rounded text-blue-700">{Math.max(minCircuits, actualCircuits)}</span>
            </li>
            <li className="flex justify-between items-center pt-2">
              <span className="text-slate-600">Total Bocas Cargadas:</span>
              <span className="font-bold text-lg">{totalBocas}</span>
            </li>
          </ul>
        </div>

        {/* --- TARJETA DE POTENCIA --- */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2 border-b pb-2">
            <Zap className="w-5 h-5 text-amber-500" />
            Detalle de Cargas
          </h4>
          <ul className="space-y-3 text-sm">
            <li className="flex justify-between">
              <span className="text-slate-600">Iluminación (IUG):</span>
              <span className="font-medium">{iluminationPower} VA</span>
            </li>
            <li className="flex justify-between">
              <span className="text-slate-600">Tomas (TUG):</span>
              <span className="font-medium">{socketsPower} VA</span>
            </li>
            {specialPower > 0 && (
              <li className="flex justify-between text-amber-700 bg-amber-50 px-2 rounded">
                <span className="font-medium">Especiales (TUE):</span>
                <span className="font-bold">{specialPower} VA</span>
              </li>
            )}
            <li className="flex justify-between border-t pt-3 mt-2">
              <span className="text-slate-600 font-bold">Corriente de Proyecto ({voltage}):</span>
              <span className="font-mono font-bold text-blue-600 text-lg">{current.toFixed(2)} A</span>
            </li>
          </ul>
        </div>
      </div>

      {/* --- SUGERENCIAS TÉCNICAS (TABLERO) --- */}
      <div className="bg-slate-900 text-white p-6 rounded-xl shadow-lg">
        <h4 className="font-bold text-lg mb-4 flex items-center gap-2 text-blue-400">
          <FileText className="w-5 h-5" />
          Dimensionamiento Sugerido
        </h4>
        
        {/* Línea Principal */}
        <div className="mb-6 pb-6 border-b border-slate-700">
          <p className="text-xs text-slate-400 uppercase tracking-wider mb-3">Línea Principal (Acometida → Tablero)</p>
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-slate-800 p-3 rounded border border-slate-700">
              <p className="text-xs text-slate-400 mb-1">Cable</p>
              <p className="text-xl font-bold text-white">{suggestedCable}</p>
            </div>
            <div className="bg-slate-800 p-3 rounded border border-slate-700">
              <p className="text-xs text-slate-400 mb-1">Térmica</p>
              <p className="text-xl font-bold text-white">{suggestedBreaker}</p>
            </div>
             {/* --- NUEVO: DISYUNTOR --- */}
            <div className="bg-blue-900/30 p-3 rounded border border-blue-500/50">
              <p className="text-xs text-blue-300 mb-1 flex items-center gap-1">
                 <ShieldCheck className="w-3 h-3" /> Disyuntor
              </p>
              <p className="text-xl font-bold text-white">{suggestedDifferential}</p>
            </div>
          </div>
        </div>

        {/* Circuitos Terminales */}
        <div>
          <p className="text-xs text-slate-400 uppercase tracking-wider mb-3">Circuitos Terminales (Salidas)</p>
          <div className="space-y-2 text-sm">
            {/* IUG */}
            <div className="flex justify-between items-center bg-slate-800/50 p-2 rounded px-3">
              <span className="text-slate-300">C1 - Iluminación (IUG)</span>
              <div className="flex gap-3">
                <span className="font-mono text-yellow-400 font-bold">1.5 mm²</span>
                <span className="text-slate-500">|</span>
                <span className="font-mono text-blue-300 font-bold">TM 10A</span>
              </div>
            </div>
            
            {/* TUG */}
            <div className="flex justify-between items-center bg-slate-800/50 p-2 rounded px-3">
              <span className="text-slate-300">C2 - Tomas (TUG)</span>
              <div className="flex gap-3">
                <span className="font-mono text-yellow-400 font-bold">2.5 mm²</span>
                <span className="text-slate-500">|</span>
                <span className="font-mono text-blue-300 font-bold">TM 16A</span>
              </div>
            </div>

            {/* TUE */}
            {specialPower > 0 && (
              <div className="flex justify-between items-center bg-slate-800/50 p-2 rounded px-3 border border-amber-900/30">
                <span className="text-amber-200">C3 - Especial (TUE/ACU)</span>
                <div className="flex gap-3">
                  <span className="font-mono text-yellow-400 font-bold">2.5 mm²</span>
                  <span className="text-slate-500">|</span>
                  <span className="font-mono text-blue-300 font-bold">TM 20A</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* --- BOTONES DE ACCIÓN --- */}
      <div className="grid md:grid-cols-2 gap-3 mt-4">
        <button
          onClick={onDownloadMemoria}
          className="flex items-center justify-center space-x-2 py-3 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 font-semibold transition-colors border border-slate-200"
        >
          <FileText className="w-5 h-5" />
          <span>Descargar Memoria</span>
        </button>

        <button
          onClick={onDownloadMateriales}
          className="flex items-center justify-center space-x-2 py-3 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 font-semibold transition-colors border border-slate-200"
        >
          <Download className="w-5 h-5" />
          <span>Descargar Materiales</span>
        </button>
      </div>

      <div className="flex space-x-3 pt-2">
        <button
          onClick={onBack}
          className="flex-1 py-3 bg-slate-200 text-slate-700 rounded-lg hover:bg-slate-300 font-semibold transition-colors"
        >
          Volver
        </button>
        <button
          onClick={onSaveProject}
          className="flex-1 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-semibold transition-colors flex items-center justify-center space-x-2 shadow-md"
        >
          <CheckCircle2 className="w-5 h-5" />
          <span>Guardar Proyecto</span>
        </button>
      </div>
    </div>
  );
}