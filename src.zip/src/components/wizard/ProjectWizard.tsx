import React, { useState } from 'react';
import { X } from 'lucide-react';
// --- CORRECCIÓN FINAL: Usamos la ortografía correcta (con 'J') según tu indicación ---
import ProjectWizardStep1 from './ProjectWizardStep1';
import ProjectWizardStep2 from './ProjectWizardStep2';
import ProjectWizardStep3 from './ProjectWizardStep3'; 
// -------------------------------------------------------------------------------------
import {
  ProjectConfig,
  EnvironmentCalculation,
  calculateProjectDemand,
  getSuggestedEnvironments,
  calculateEnvironmentBocas,
} from '../../lib/electrical-rules';

interface ProjectWizardProps {
  onClose: () => void;
  onSaveProject: (data: any) => void;
}

export default function ProjectWizard({
  onClose,
  onSaveProject,
}: ProjectWizardProps) {
  const [step, setStep] = useState(1);
  
  // Inicializamos con el nuevo campo workType para evitar parpadeos
  const [config, setConfig] = useState<ProjectConfig>({
    clientName: '',
    clientPhone: '',
    destination: 'vivienda',
    voltage: '220V',
    projectType: 'nueva',
    surfaceArea: 0,
    workType: 'budget_certification',
  });

  const [environments, setEnvironments] = useState<EnvironmentCalculation[]>([]);

  const handleStep1Next = () => {
    if (environments.length === 0) {
      const suggested = getSuggestedEnvironments(config.destination);
      const initializedEnvs = suggested.map((env) => {
        const bocas = calculateEnvironmentBocas(env);
        return { ...env, ...bocas };
      });
      setEnvironments(initializedEnvs);
    }
    setStep(2);
  };

  const handleCalculate = () => {
    setStep(3);
  };

  // Helper para calcular grado
  function calculateGrade(surface: number, destination: string): any {
      if(destination === 'local') return 'elevado';
      if(surface < 60) return 'minimo';
      if(surface <= 130) return 'medio';
      if(surface <= 200) return 'elevado';
      return 'superior';
  }

  const calculation = calculateProjectDemand(
    environments,
    calculateGrade(config.surfaceArea, config.destination),
    config.voltage
  );

  const handleSave = () => {
    onSaveProject({
      config,
      environments,
      calculation,
      createdAt: new Date(),
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-100">
          <div>
            <h2 className="text-xl font-bold text-slate-900">
              {step === 1 && 'Nuevo Proyecto'}
              {step === 2 && 'Ambientes y Cargas'}
              {step === 3 && 'Resultados del Cálculo'}
            </h2>
            <p className="text-sm text-slate-500">
              Paso {step} de 3
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-100 rounded-full transition-colors"
          >
            <X className="w-6 h-6 text-slate-400" />
          </button>
        </div>

        {/* Cuerpo */}
        <div className="p-6 overflow-y-auto flex-1">
          {step === 1 && (
            <ProjectWizardStep1
              config={config}
              onChange={setConfig}
              onNext={handleStep1Next}
            />
          )}

          {step === 2 && (
            <ProjectWizardStep2
              config={config}
              environments={environments}
              onUpdateEnvironments={setEnvironments}
              onBack={() => setStep(1)}
              onCalculate={handleCalculate}
            />
          )}

          {step === 3 && (
            <ProjectWizardStep3
              config={config}
              environments={environments}
              calculation={calculation}
              onDownloadMemoria={() => console.log('Descargar Memoria')}
              onDownloadMateriales={() => console.log('Descargar Materiales')}
              onSaveProject={handleSave}
              onBack={() => setStep(2)}
            />
          )}
        </div>
      </div>
    </div>
  );
}
