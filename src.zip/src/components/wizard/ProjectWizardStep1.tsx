import React from 'react';
import { User, Phone, Home, Zap, FileText, Hammer, ShieldCheck } from 'lucide-react';
import { ProjectConfig } from '../../../lib/electrical-rules';

interface Step1Props {
  config: ProjectConfig;
  onChange: (config: ProjectConfig) => void;
  onNext: () => void;
}

export default function ProjectWizardStep1({
  config,
  onChange,
  onNext,
}: Step1Props) {
  
  const handleChange = (field: keyof ProjectConfig, value: any) => {
    onChange({ ...config, [field]: value });
  };

  const isComplete =
    config.clientName &&
    config.destination &&
    config.voltage &&
    config.surfaceArea > 0 &&
    config.workType; // Validamos que haya elegido ruta

  return (
    <div className="space-y-8">
      {/* --- SECCIÓN 1: DATOS DEL CLIENTE --- */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
          <User className="w-5 h-5 text-blue-600" />
          Datos del Cliente
        </h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Nombre / Razón Social
            </label>
            <input
              type="text"
              className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Ej: Juan Pérez"
              value={config.clientName}
              onChange={(e) => handleChange('clientName', e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Teléfono (Opcional)
            </label>
            <div className="relative">
              <Phone className="absolute left-3 top-3.5 w-4 h-4 text-slate-400" />
              <input
                type="tel"
                className="w-full p-3 pl-10 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Ej: 351..."
                value={config.clientPhone}
                onChange={(e) => handleChange('clientPhone', e.target.value)}
              />
            </div>
          </div>
        </div>
      </div>

      {/* --- SECCIÓN 2: RUTA DE TRABAJO (A-B-C) --- */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
          <FileText className="w-5 h-5 text-blue-600" />
          Tipo de Trabajo (Ruta)
        </h3>
        <div className="grid md:grid-cols-3 gap-4">
          {/* RUTA A */}
          <button
            onClick={() => handleChange('workType', 'certification_only')}
            className={`p-4 rounded-xl border-2 text-left transition-all ${
              config.workType === 'certification_only'
                ? 'border-blue-600 bg-blue-50 ring-1 ring-blue-600'
                : 'border-slate-200 hover:border-blue-300 hover:bg-slate-50'
            }`}
          >
            <div className="flex items-start justify-between mb-2">
              <ShieldCheck className={`w-6 h-6 ${config.workType === 'certification_only' ? 'text-blue-600' : 'text-slate-400'}`} />
              <span className="text-xs font-bold bg-blue-100 text-blue-800 px-2 py-0.5 rounded">RUTA A</span>
            </div>
            <h4 className="font-bold text-slate-900 mb-1">Solo Certificación</h4>
            <p className="text-xs text-slate-500">Instalación APTA. Generar certificado directo.</p>
          </button>

          {/* RUTA B */}
          <button
            onClick={() => handleChange('workType', 'budget_certification')}
            className={`p-4 rounded-xl border-2 text-left transition-all ${
              config.workType === 'budget_certification'
                ? 'border-blue-600 bg-blue-50 ring-1 ring-blue-600'
                : 'border-slate-200 hover:border-blue-300 hover:bg-slate-50'
            }`}
          >
            <div className="flex items-start justify-between mb-2">
              <Hammer className={`w-6 h-6 ${config.workType === 'budget_certification' ? 'text-blue-600' : 'text-slate-400'}`} />
              <span className="text-xs font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded">RUTA B</span>
            </div>
            <h4 className="font-bold text-slate-900 mb-1">Obra + Certificación</h4>
            <p className="text-xs text-slate-500">Presupuesto, ejecución y posterior certificado.</p>
          </button>

          {/* RUTA C */}
          <button
            onClick={() => handleChange('workType', 'private_job')}
            className={`p-4 rounded-xl border-2 text-left transition-all ${
              config.workType === 'private_job'
                ? 'border-blue-600 bg-blue-50 ring-1 ring-blue-600'
                : 'border-slate-200 hover:border-blue-300 hover:bg-slate-50'
            }`}
          >
            <div className="flex items-start justify-between mb-2">
              <Zap className={`w-6 h-6 ${config.workType === 'private_job' ? 'text-blue-600' : 'text-slate-400'}`} />
              <span className="text-xs font-bold bg-slate-100 text-slate-800 px-2 py-0.5 rounded">RUTA C</span>
            </div>
            <h4 className="font-bold text-slate-900 mb-1">Trabajo Particular</h4>
            <p className="text-xs text-slate-500">Sin certificado oficial. Informe técnico privado.</p>
          </button>
        </div>
      </div>

      {/* --- SECCIÓN 3: DATOS TÉCNICOS --- */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
          <Home className="w-5 h-5 text-blue-600" />
          Detalles del Inmueble
        </h3>
        
        <div className="grid md:grid-cols-2 gap-6">
          {/* Destino */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Destino
            </label>
            <div className="flex gap-3">
              <label className={`flex-1 cursor-pointer border rounded-lg p-3 flex items-center gap-2 transition-colors ${config.destination === 'vivienda' ? 'bg-blue-50 border-blue-500 ring-1 ring-blue-500' : 'hover:bg-slate-50'}`}>
                <input
                  type="radio"
                  name="destination"
                  className="hidden"
                  checked={config.destination === 'vivienda'}
                  onChange={() => handleChange('destination', 'vivienda')}
                />
                <Home className="w-4 h-4 text-slate-500" />
                <span className="text-sm font-medium">Vivienda</span>
              </label>
              
              <label className={`flex-1 cursor-pointer border rounded-lg p-3 flex items-center gap-2 transition-colors ${config.destination === 'local' ? 'bg-blue-50 border-blue-500 ring-1 ring-blue-500' : 'hover:bg-slate-50'}`}>
                <input
                  type="radio"
                  name="destination"
                  className="hidden"
                  checked={config.destination === 'local'}
                  onChange={() => handleChange('destination', 'local')}
                />
                <BriefcaseIcon />
                <span className="text-sm font-medium">Local / Ofic.</span>
              </label>
            </div>
          </div>

          {/* Acometida */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Acometida
            </label>
            <div className="flex gap-3">
              <label className={`flex-1 cursor-pointer border rounded-lg p-3 flex items-center gap-2 transition-colors ${config.voltage === '220V' ? 'bg-blue-50 border-blue-500 ring-1 ring-blue-500' : 'hover:bg-slate-50'}`}>
                <input
                  type="radio"
                  name="voltage"
                  className="hidden"
                  checked={config.voltage === '220V'}
                  onChange={() => handleChange('voltage', '220V')}
                />
                <span className="text-sm font-medium">Monofásica (220V)</span>
              </label>
              
              <label className={`flex-1 cursor-pointer border rounded-lg p-3 flex items-center gap-2 transition-colors ${config.voltage === '380V' ? 'bg-blue-50 border-blue-500 ring-1 ring-blue-500' : 'hover:bg-slate-50'}`}>
                <input
                  type="radio"
                  name="voltage"
                  className="hidden"
                  checked={config.voltage === '380V'}
                  onChange={() => handleChange('voltage', '380V')}
                />
                <span className="text-sm font-medium">Trifásica (380V)</span>
              </label>
            </div>
          </div>

          {/* Superficie */}
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Superficie Límite de Aplicación (SLA)
            </label>
            <div className="relative">
              <input
                type="number"
                className="w-full p-3 pr-12 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Ej: 65"
                value={config.surfaceArea || ''}
                onChange={(e) => handleChange('surfaceArea', Number(e.target.value))}
              />
              <span className="absolute right-4 top-3.5 text-slate-400 font-medium">
                m²
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Superficie cubierta + 50% de superficie semicubierta.
            </p>
          </div>
        </div>
      </div>

      {/* Botón Siguiente */}
      <button
        onClick={onNext}
        disabled={!isComplete}
        className={`w-full py-4 rounded-lg font-bold text-lg transition-all ${
          isComplete
            ? 'bg-blue-600 text-white hover:bg-blue-700 shadow-lg'
            : 'bg-slate-200 text-slate-400 cursor-not-allowed'
        }`}
      >
        Siguiente Paso
      </button>
    </div>
  );
}

// Icono auxiliar
function BriefcaseIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-500"><rect width="20" height="14" x="2" y="7" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>
  );
}