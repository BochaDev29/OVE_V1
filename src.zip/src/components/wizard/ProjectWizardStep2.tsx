import React from 'react';
import { Plus, Trash2, Home, Calculator, Lightbulb, Plug, Zap } from 'lucide-react';
import {
  ProjectConfig,
  EnvironmentCalculation,
  calculateEnvironmentBocas,
} from '../../lib/electrical-rules';

interface Step2Props {
  config: ProjectConfig;
  environments: EnvironmentCalculation[];
  onUpdateEnvironments: (envs: EnvironmentCalculation[]) => void;
  onBack: () => void;
  onCalculate: () => void;
}

export default function ProjectWizardStep2({
  config,
  environments,
  onUpdateEnvironments,
  onBack,
  onCalculate,
}: Step2Props) {
  
  const handleAddEnvironment = () => {
    const newEnv: EnvironmentCalculation = {
      id: crypto.randomUUID(),
      name: 'Nuevo Ambiente',
      surface: 0,
      lights: 0,
      regularOutlets: 0,
      specialOutlets: 0,
    };
    onUpdateEnvironments([...environments, newEnv]);
  };

  const handleRemoveEnvironment = (id: string) => {
    onUpdateEnvironments(environments.filter((e) => e.id !== id));
  };

  const handleUpdateEnvironment = (id: string, field: keyof EnvironmentCalculation, value: any) => {
    const updatedEnvs = environments.map((env) => {
      if (env.id === id) {
        const updatedEnv = { ...env, [field]: value };
        
        // Si cambia el TIPO o la SUPERFICIE, recalculamos los MÍNIMOS sugeridos
        // PERO si el usuario edita las bocas manualmente (lights/outlets), NO recalculamos
        if (field === 'name' || field === 'surface') {
           // Solo autocalculamos si no es "personalizado"
           // Opcional: Podríamos dejar que siempre sugiera y el usuario corrija después
           const suggestions = calculateEnvironmentBocas(updatedEnv);
           
           // Si es 'Otro', no sobrescribimos con ceros si el usuario ya puso datos
           if (!updatedEnv.name.toLowerCase().includes('otro') && !updatedEnv.name.toLowerCase().includes('personalizado')) {
               return { ...updatedEnv, ...suggestions };
           }
        }
        return updatedEnv;
      }
      return env;
    });
    onUpdateEnvironments(updatedEnvs);
  };

  const totalSurface = environments.reduce((acc, curr) => acc + (Number(curr.surface) || 0), 0);
  const totalBocas = environments.reduce((acc, curr) => 
    acc + (Number(curr.lights) || 0) + (Number(curr.regularOutlets) || 0) + (Number(curr.specialOutlets) || 0), 0
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Definir Ambientes</h2>
          <p className="text-sm text-slate-500">
            Tabla 770.7.III - Puedes editar las cantidades manualmente.
          </p>
        </div>
        <button
          onClick={handleAddEnvironment}
          className="flex items-center space-x-2 px-4 py-2 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 font-medium transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Agregar</span>
        </button>
      </div>

      <div className="space-y-3">
        {environments.map((env) => (
          <div
            key={env.id}
            className="p-4 bg-white border border-slate-200 rounded-lg shadow-sm hover:border-blue-300 transition-all"
          >
            <div className="flex flex-col md:flex-row gap-4 items-end">
              
              {/* 1. Selección de Ambiente */}
              <div className="flex-1 min-w-[200px]">
                <label className="block text-xs font-medium text-slate-700 mb-1">Ambiente</label>
                <select
                  className="w-full p-2 border border-slate-300 rounded text-sm focus:ring-2 focus:ring-blue-500"
                  value={['sala','comedor','dormitorio','cocina','baño','vestibulo','pasillo','lavadero','balcon','garaje','vestidor','otro'].find(t => env.name.toLowerCase().includes(t)) ? env.name.toLowerCase() : 'otro'}
                  onChange={(e) => {
                     const val = e.target.value;
                     const newName = val === 'otro' ? 'Personalizado' : val.charAt(0).toUpperCase() + val.slice(1);
                     handleUpdateEnvironment(env.id, 'name', newName);
                  }}
                >
                  <option value="sala">Sala / Comedor / Estar</option>
                  <option value="dormitorio">Dormitorio</option>
                  <option value="cocina">Cocina</option>
                  <option value="baño">Baño / Toilette</option>
                  <option value="vestibulo">Vestíbulo / Hall</option>
                  <option value="pasillo">Pasillo / Circulación</option>
                  <option value="lavadero">Lavadero</option>
                  <option value="balcon">Balcón / Galería</option>
                  <option value="garaje">Garaje / Cochera</option>
                  <option value="vestidor">Vestidor</option>
                  <option value="otro">Otro / Personalizado</option>
                </select>
              </div>

              {/* 2. Superficie */}
              <div className="w-24">
                <label className="block text-xs font-medium text-slate-700 mb-1">m²</label>
                <input
                  type="number"
                  min="0"
                  className="w-full p-2 border border-slate-300 rounded text-sm focus:ring-2 focus:ring-blue-500"
                  value={env.surface}
                  onChange={(e) => handleUpdateEnvironment(env.id, 'surface', parseFloat(e.target.value) || 0)}
                />
              </div>

              {/* 3. INPUTS EDITABLES DE BOCAS */}
              <div className="flex gap-2">
                
                {/* IUG */}
                <div className="w-16">
                   <label className="block text-xs font-bold text-yellow-600 mb-1 flex items-center gap-1">
                     <Lightbulb className="w-3 h-3" /> IUG
                   </label>
                   <input
                    type="number"
                    min="0"
                    className="w-full p-2 border border-yellow-200 bg-yellow-50 rounded text-sm font-bold text-center focus:ring-2 focus:ring-yellow-500"
                    value={env.lights}
                    onChange={(e) => handleUpdateEnvironment(env.id, 'lights', parseInt(e.target.value) || 0)}
                   />
                </div>

                {/* TUG */}
                <div className="w-16">
                   <label className="block text-xs font-bold text-blue-600 mb-1 flex items-center gap-1">
                     <Plug className="w-3 h-3" /> TUG
                   </label>
                   <input
                    type="number"
                    min="0"
                    className="w-full p-2 border border-blue-200 bg-blue-50 rounded text-sm font-bold text-center focus:ring-2 focus:ring-blue-500"
                    value={env.regularOutlets}
                    onChange={(e) => handleUpdateEnvironment(env.id, 'regularOutlets', parseInt(e.target.value) || 0)}
                   />
                </div>

                {/* TUE */}
                <div className="w-16">
                   <label className="block text-xs font-bold text-red-600 mb-1 flex items-center gap-1">
                     <Zap className="w-3 h-3" /> TUE
                   </label>
                   <input
                    type="number"
                    min="0"
                    className="w-full p-2 border border-red-200 bg-red-50 rounded text-sm font-bold text-center focus:ring-2 focus:ring-red-500"
                    value={env.specialOutlets}
                    onChange={(e) => handleUpdateEnvironment(env.id, 'specialOutlets', parseInt(e.target.value) || 0)}
                   />
                </div>
              </div>

              {/* Botón Borrar */}
              <button
                onClick={() => handleRemoveEnvironment(env.id)}
                className="p-2 mb-0.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded transition-colors"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
            
            {/* Nombre editable solo si es personalizado */}
            {(env.name === 'Personalizado' || !['Sala', 'Dormitorio', 'Cocina', 'Baño', 'Vestibulo', 'Pasillo', 'Lavadero', 'Balcon', 'Garaje', 'Vestidor'].some(t => env.name.startsWith(t))) && (
               <div className="mt-2">
                 <input 
                    type="text" 
                    placeholder="Nombre del ambiente (Ej: Quincho)"
                    className="w-full p-2 text-sm border-b border-slate-200 focus:outline-none focus:border-blue-500 text-slate-600"
                    value={env.name}
                    onChange={(e) => handleUpdateEnvironment(env.id, 'name', e.target.value)}
                 />
               </div>
            )}
          </div>
        ))}

        {environments.length === 0 && (
          <div className="text-center py-10 bg-slate-50 rounded-lg border-2 border-dashed border-slate-300">
            <Home className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-slate-500">No hay ambientes cargados.</p>
            <button 
              onClick={handleAddEnvironment}
              className="mt-2 text-blue-600 font-medium hover:underline"
            >
              Comenzar
            </button>
          </div>
        )}
      </div>

      <div className="bg-slate-900 text-white p-4 rounded-lg flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex gap-6 text-sm">
          <div>
            <span className="text-slate-400 block text-xs">Sup. Total</span>
            <span className="font-bold text-lg">{totalSurface.toFixed(2)} m²</span>
          </div>
          <div>
            <span className="text-slate-400 block text-xs">Bocas Totales</span>
            <span className="font-bold text-lg">{totalBocas}</span>
          </div>
        </div>

        <div className="flex gap-3 w-full md:w-auto">
          <button onClick={onBack} className="px-4 py-2 bg-slate-700 text-slate-200 rounded hover:bg-slate-600">
            Atrás
          </button>
          <button
            onClick={onCalculate}
            disabled={environments.length === 0}
            className={`flex items-center gap-2 px-6 py-2 rounded font-bold transition-all ${
              environments.length > 0 ? 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg' : 'bg-slate-700 text-slate-500 cursor-not-allowed'
            }`}
          >
            <Calculator className="w-4 h-4" />
            Calcular
          </button>
        </div>
      </div>
    </div>
  );
}