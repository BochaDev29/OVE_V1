import React, { useState, useRef, useEffect } from 'react';
import { Stage, Layer, Line, Transformer, Rect, Circle, Group, Text, Path } from 'react-konva';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import jsPDF from 'jspdf';

// Componentes hijos
import PlannerToolbar, { type Tool } from './PlannerToolbar';
import PlannerSidebar from './PlannerSidebar';
import MaterialReportModal from './MaterialReportModal';
import ProjectInfoModal, { type ProjectData } from './ProjectInfoModal';

// --- TIPOS ---
interface Wall { id: string; points: number[]; }
interface SymbolItem { id: string; x: number; y: number; type: any; rotation: number; label?: string; color?: string; fontSize?: number; }
interface Pipe { id: string; points: number[]; color: string; type: 'straight' | 'curved'; }
interface AuxLine { id: string; points: number[]; }

export default function PlannerCanvas() {
  const navigate = useNavigate();
  
  // --- ESTADOS ---
  const [tool, setTool] = useState<Tool>('select');
  const [symbols, setSymbols] = useState<SymbolItem[]>([]);
  const [walls, setWalls] = useState<Wall[]>([]);
  const [pipes, setPipes] = useState<Pipe[]>([]);
  const [auxLines, setAuxLines] = useState<AuxLine[]>([]);
  const [pixelsPerMeter, setPixelsPerMeter] = useState<number>(50); 
  const [currentCircuitColor, setCurrentCircuitColor] = useState<string>('#dc2626');
  const [currentPipeType, setCurrentPipeType] = useState<'straight' | 'curved'>('curved');
  const [projectData, setProjectData] = useState<ProjectData>({
    projectName: '', address: '', installer: '', category: '1:50', date: new Date().toLocaleDateString('es-AR')
  });

  const [showMaterialModal, setShowMaterialModal] = useState(false);
  const [showProjectInfoModal, setShowProjectInfoModal] = useState(false);

  // ZOOM / PAN
  const [stageScale, setStageScale] = useState(1);
  const [stagePos, setStagePos] = useState({ x: 50, y: 50 });

  const stageRef = useRef<any>(null);
  const transformerRef = useRef<any>(null);
  const isDrawing = useRef(false);

  // Temporales
  const [currentWall, setCurrentWall] = useState<number[] | null>(null);
  const [currentAuxLine, setCurrentAuxLine] = useState<number[] | null>(null);
  const [pipeStartPoint, setPipeStartPoint] = useState<{x: number, y: number} | null>(null);
  const [currentPipePreview, setCurrentPipePreview] = useState<number[] | null>(null);
  const [calibrationLine, setCalibrationLine] = useState<number[] | null>(null);
  const [selectedId, selectShape] = useState<string | null>(null);

  // --- CURSOR ---
  const getCursorStyle = () => {
    if (tool === 'select') return 'default';
    if (['wall', 'pipe', 'aux_line', 'calibrate'].includes(tool)) return 'crosshair';
    return 'copy'; 
  };

  // --- EFECTOS ---
  useEffect(() => {
    if (selectedId && transformerRef.current) {
      const node = stageRef.current.findOne('#' + selectedId);
      const isLine = walls.find(w => w.id === selectedId) || auxLines.find(a => a.id === selectedId);
      if (node && !isLine) {
        transformerRef.current.nodes([node]);
        transformerRef.current.getLayer().batchDraw();
      } else {
        transformerRef.current.nodes([]);
      }
    } else {
      transformerRef.current?.nodes([]);
    }
  }, [selectedId, walls, auxLines]);

  useEffect(() => {
    if (selectedId && currentCircuitColor) {
        setPipes(prev => prev.map(p => p.id === selectedId ? { ...p, color: currentCircuitColor } : p));
    }
  }, [currentCircuitColor]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.key === 'Delete' || e.key === 'Backspace')) handleDeleteSelected();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedId]);

  // --- ACCIONES ---
  const handleDeleteSelected = () => {
    if (selectedId) {
      setSymbols(prev => prev.filter(item => item.id !== selectedId));
      setWalls(prev => prev.filter(item => item.id !== selectedId));
      setPipes(prev => prev.filter(item => item.id !== selectedId));
      setAuxLines(prev => prev.filter(item => item.id !== selectedId));
      selectShape(null);
    }
  };

  const handleClearAll = () => {
    if (window.confirm("¿Estás seguro de que quieres BORRAR TODO el plano?")) {
      setSymbols([]); setWalls([]); setPipes([]); setAuxLines([]);
      selectShape(null);
    }
  };

  const handleCalibrateEnd = (points: number[]) => {
      const dx = points[2] - points[0];
      const dy = points[3] - points[1];
      const distPixels = Math.sqrt(dx*dx + dy*dy);
      if (distPixels < 10) return; 

      const metersStr = window.prompt("¿Cuántos METROS reales mide la línea?", "1.0");
      if (metersStr) {
          const meters = parseFloat(metersStr.replace(',', '.'));
          if (!isNaN(meters) && meters > 0) {
              const newPPM = distPixels / meters;
              setPixelsPerMeter(newPPM);
              alert(`¡Escala Calibrada! 1 Metro = ${Math.round(newPPM)} pixeles.`);
              setProjectData(prev => ({...prev, category: `1:${Math.round(100 * 50 / newPPM)}`}));
          }
      }
  };

  const handleWheel = (e: any) => {
    e.evt.preventDefault();
    const scaleBy = 1.1;
    const stage = e.target.getStage();
    const oldScale = stage.scaleX();
    const mousePointTo = {
      x: stage.getPointerPosition().x / oldScale - stage.x() / oldScale,
      y: stage.getPointerPosition().y / oldScale - stage.y() / oldScale,
    };
    const newScale = e.evt.deltaY < 0 ? oldScale * scaleBy : oldScale / scaleBy;
    setStageScale(newScale);
    setStagePos({
      x: -(mousePointTo.x - stage.getPointerPosition().x / newScale) * newScale,
      y: -(mousePointTo.y - stage.getPointerPosition().y / newScale) * newScale,
    });
  };

  const handleUpdateLabel = (id: string, currentLabel?: string) => {
    const newLabel = window.prompt("Editar etiqueta:", currentLabel || "");
    if (newLabel !== null) setSymbols(symbols.map(s => s.id === id ? { ...s, label: newLabel } : s));
  };

  // --- CLICS ---
  const handleMouseDown = (e: any) => {
    if (e.evt.button === 2 || e.evt.ctrlKey) return;
    const stage = e.target.getStage();
    const transform = stage.getAbsoluteTransform().copy(); transform.invert();
    const pos = transform.point(stage.getPointerPosition());
    const isBackgroundClick = e.target === stage;

    if (tool === 'select') {
        if (isBackgroundClick) selectShape(null);
        return;
    }
    if (tool === 'calibrate') {
        isDrawing.current = true;
        setCalibrationLine([pos.x, pos.y, pos.x, pos.y]);
        return;
    }
    if (tool === 'text') {
      e.evt.preventDefault(); e.cancelBubble = true;
      const textValue = window.prompt("Ingrese texto:");
      if (textValue) setSymbols([...symbols, { id: `text-${Date.now()}`, type: 'text', x: pos.x, y: pos.y, rotation: 0, label: textValue, color: '#000000', fontSize: 12 }]);
      setTool('select'); return;
    }
    if (tool === 'table') {
      setSymbols([...symbols, { id: `table-${Date.now()}`, type: 'table', x: pos.x, y: pos.y, rotation: 0, label: 'Tabla' }]);
      setTool('select'); return;
    }
    if (tool === 'wall') {
      isDrawing.current = true;
      setCurrentWall([pos.x, pos.y, pos.x, pos.y]);
      selectShape(null); return;
    }
    if (tool === 'aux_line') {
      isDrawing.current = true;
      setCurrentAuxLine([pos.x, pos.y, pos.x, pos.y]);
      selectShape(null); return;
    }
    if (tool === 'pipe') {
      if (!pipeStartPoint) {
        setPipeStartPoint({ x: pos.x, y: pos.y });
        setCurrentPipePreview([pos.x, pos.y, pos.x, pos.y]);
      } else {
        setPipes([...pipes, { id: `pipe-${Date.now()}`, points: [pipeStartPoint.x, pipeStartPoint.y, pos.x, pos.y], color: currentCircuitColor, type: currentPipeType }]);
        setPipeStartPoint(null); setCurrentPipePreview(null);
      }
      selectShape(null); return;
    }
    if (isBackgroundClick && tool !== 'select') {
       setSymbols([...symbols, { id: `${tool}-${Date.now()}`, type: tool, x: pos.x, y: pos.y, rotation: 0, label: '' }]);
       setTool('select');
    }
  };

  const handleMouseMove = (e: any) => {
    const stage = e.target.getStage();
    const transform = stage.getAbsoluteTransform().copy(); transform.invert();
    const pos = transform.point(stage.getPointerPosition());

    if (isDrawing.current) {
        if (tool === 'wall' && currentWall) setCurrentWall([currentWall[0], currentWall[1], pos.x, pos.y]);
        if (tool === 'aux_line' && currentAuxLine) setCurrentAuxLine([currentAuxLine[0], currentAuxLine[1], pos.x, pos.y]);
        if (tool === 'calibrate' && calibrationLine) setCalibrationLine([calibrationLine[0], calibrationLine[1], pos.x, pos.y]);
    }
    if (tool === 'pipe' && pipeStartPoint) setCurrentPipePreview([pipeStartPoint.x, pipeStartPoint.y, pos.x, pos.y]);
  };

  const handleMouseUp = () => {
    if (isDrawing.current) {
        if (tool === 'wall' && currentWall) {
            if (Math.abs(currentWall[2] - currentWall[0]) > 5 || Math.abs(currentWall[3] - currentWall[1]) > 5) {
                setWalls([...walls, { id: `wall-${Date.now()}`, points: currentWall }]);
            }
            setCurrentWall(null);
        }
        if (tool === 'aux_line' && currentAuxLine) {
            if (Math.abs(currentAuxLine[2] - currentAuxLine[0]) > 5 || Math.abs(currentAuxLine[3] - currentAuxLine[1]) > 5) {
                setAuxLines([...auxLines, { id: `aux-${Date.now()}`, points: currentAuxLine }]);
            }
            setCurrentAuxLine(null);
        }
        if (tool === 'calibrate' && calibrationLine) {
            handleCalibrateEnd(calibrationLine);
            setCalibrationLine(null);
            setTool('select'); 
        }
        isDrawing.current = false;
    }
  };

  const updateLinePoint = (id: string, type: 'wall'|'aux', pointIndex: 0|2, newX: number, newY: number) => {
      if (type === 'wall') {
          setWalls(prev => prev.map(w => w.id !== id ? w : {...w, points: pointIndex===0 ? [newX, newY, w.points[2], w.points[3]] : [w.points[0], w.points[1], newX, newY]} ));
      } else {
          setAuxLines(prev => prev.map(a => a.id !== id ? a : {...a, points: pointIndex===0 ? [newX, newY, a.points[2], a.points[3]] : [a.points[0], a.points[1], newX, newY]} ));
      }
  };

  const renderGrid = () => {
    const step = pixelsPerMeter;
    const lines = [];
    for (let i = 0; i < 1000; i += step) lines.push(<Line key={`v${i}`} points={[i, 0, i, 700]} stroke="#f1f5f9" strokeWidth={1} listening={false} />);
    for (let j = 0; j < 700; j += step) lines.push(<Line key={`h${j}`} points={[0, j, 1000, j]} stroke="#f1f5f9" strokeWidth={1} listening={false} />);
    return <Group name="grid">{lines}</Group>;
  };

  const renderSelectionNodes = () => {
      if (!selectedId || tool !== 'select') return null;
      const selectedWall = walls.find(w => w.id === selectedId);
      const selectedAux = auxLines.find(a => a.id === selectedId);

      if (selectedWall) {
          return (
              <>
                <Circle x={selectedWall.points[0]} y={selectedWall.points[1]} radius={6} fill="#3b82f6" stroke="white" strokeWidth={2} draggable onDragMove={(e) => { const pos = e.target.position(); updateLinePoint(selectedWall.id, 'wall', 0, pos.x, pos.y); }} />
                <Circle x={selectedWall.points[2]} y={selectedWall.points[3]} radius={6} fill="#3b82f6" stroke="white" strokeWidth={2} draggable onDragMove={(e) => { const pos = e.target.position(); updateLinePoint(selectedWall.id, 'wall', 2, pos.x, pos.y); }} />
              </>
          );
      }
      if (selectedAux) {
          return (
            <>
                <Circle x={selectedAux.points[0]} y={selectedAux.points[1]} radius={5} fill="#22c55e" stroke="white" strokeWidth={2} draggable onDragMove={(e) => { const pos = e.target.position(); updateLinePoint(selectedAux.id, 'aux', 0, pos.x, pos.y); }} />
                <Circle x={selectedAux.points[2]} y={selectedAux.points[3]} radius={5} fill="#22c55e" stroke="white" strokeWidth={2} draggable onDragMove={(e) => { const pos = e.target.position(); updateLinePoint(selectedAux.id, 'aux', 2, pos.x, pos.y); }} />
            </>
          );
      }
      return null;
  };

  const renderSymbol = (sym: SymbolItem) => {
    if (!sym) return null;
    if (sym.type === 'text' || sym.type === 'label') {
      return (
        <Text key={sym.id} id={sym.id} x={sym.x} y={sym.y} text={sym.label || "Texto"} fontSize={sym.fontSize || 12} fill={sym.color || "black"} draggable={tool === 'select'}
          onClick={(e) => { e.cancelBubble = true; if(tool==='select') selectShape(sym.id); }}
          onDblClick={(e) => { e.cancelBubble = true; handleUpdateLabel(sym.id, sym.label); }}
        />
      );
    }
    if (sym.type === 'table') {
      return (
        <Group key={sym.id} id={sym.id} x={sym.x} y={sym.y} draggable={tool === 'select'} onClick={() => tool === 'select' && selectShape(sym.id)}>
          <Rect x={0} y={0} width={200} height={150} fill="white" stroke="black" strokeWidth={1} />
          <Line points={[100, 0, 100, 150]} stroke="black" strokeWidth={1} />
          <Line points={[0, 30, 200, 30]} stroke="black" strokeWidth={1} />
          <Line points={[0, 60, 200, 60]} stroke="black" strokeWidth={1} />
          <Line points={[0, 90, 200, 90]} stroke="black" strokeWidth={1} />
          <Line points={[0, 120, 200, 120]} stroke="black" strokeWidth={1} />
        </Group>
      );
    }

    let pathData = "", strokeColor = "#000000", fillColor = "transparent";
    switch (sym.type) {
      case 'light': pathData = "M-10,0 A10,10 0 1,0 10,0 A10,10 0 1,0 -10,0 M-7,-7 L7,7 M-7,7 L7,-7"; strokeColor = "#dc2626"; break;
      case 'wall_light': pathData = "M-8,0 A8,8 0 1,0 8,0 A8,8 0 1,0 -8,0 M0,8 L0,15 M-5,15 L5,15"; strokeColor = "#dc2626"; break;
      case 'outlet': pathData = "M-18,0 L18,0 M-10,0 A10,10 0 0,1 10,0 M0,-10 L0,-20"; strokeColor = "#2563eb"; break;
      case 'ac': pathData = "M-18,0 L18,0 M-10,0 A10,10 0 0,1 10,0 M0,-10 L0,-20"; strokeColor = "#7c3aed"; fillColor = "#7c3aed"; break;
      case 'switch': pathData = "M-5,0 A5,5 0 1,0 5,0 A5,5 0 1,0 -5,0 M0,0 L15,-15"; strokeColor = "#475569"; fillColor = "#475569"; break;
      case 'fan': pathData = "M-2,0 A2,2 0 1,0 2,0 A2,2 0 1,0 -2,0 M0,0 L0,-12 M0,0 L10,6 M0,0 L-10,6"; strokeColor = "#059669"; break;
      case 'board': pathData = "M-15,-10 h30 v20 h-30 z M-15,-10 L15,10 M-15,10 L15,-10"; strokeColor = "#b91c1c"; fillColor = "#fee2e2"; break;
      case 'tpu': pathData = "M-15,-10 h30 v20 h-30 z M-15,10 L15,-10"; strokeColor = "#b91c1c"; fillColor = "#fee2e2"; break; 
      case 'ground': pathData = "M0,-5 L0,5 M-8,5 L8,5 M-5,9 L5,9 M-2,13 L2,13"; strokeColor = "#15803d"; break;
      case 'cp': 
        return (
            <Group key={sym.id} id={sym.id} x={sym.x} y={sym.y} draggable={tool === 'select'} onClick={() => tool === 'select' && selectShape(sym.id)}>
                 <Rect x={-10} y={-10} width={20} height={20} stroke="#000000" strokeWidth={2} fill="white" />
                 {sym.label && <Text text={sym.label} fontSize={10} x={12} y={-5} fill="#64748b" />}
            </Group>
        );
    }
    
    return (
      <Group key={sym.id} id={sym.id} x={sym.x} y={sym.y} rotation={sym.rotation || 0} draggable={tool === 'select'} onClick={() => tool === 'select' && selectShape(sym.id)} onTap={() => tool === 'select' && selectShape(sym.id)}>
        <Path data={pathData} stroke={strokeColor} strokeWidth={2} fill={fillColor} lineCap="round" lineJoin="round" />
        {sym.label && <Text text={sym.label} fontSize={10} x={10} y={10} rotation={-1*(sym.rotation||0)} fill="#64748b" />}
      </Group>
    );
  };

  const handleDownloadPDF = () => {
    if (!stageRef.current) return;
    const oldScale = stageRef.current.scaleX();
    const oldPos = stageRef.current.position();
    stageRef.current.scale({ x: 1, y: 1 }); stageRef.current.position({ x: 0, y: 0 });
    
    const elementsToHide = ['.grid', '.rotulo-visual', '.paper-shadow', '.paper-bg'];
    elementsToHide.forEach(sel => stageRef.current.findOne(sel)?.hide());
    if(transformerRef.current) transformerRef.current.nodes([]); 

    setTimeout(() => {
        try {
            const dataUri = stageRef.current.toDataURL({ pixelRatio: 2, x: 0, y: 0, width: 1000, height: 700 });
            
            stageRef.current.scale({ x: oldScale, y: oldScale }); stageRef.current.position(oldPos);
            elementsToHide.forEach(sel => stageRef.current.findOne(sel)?.show());

            const doc = new jsPDF('l', 'mm', 'a4');
            const pw = doc.internal.pageSize.getWidth(); const ph = doc.internal.pageSize.getHeight();
            const iw = 277; const ih = 190; const ix = (pw - iw) / 2; const iy = (ph - ih) / 2;
            
            doc.addImage(dataUri, 'PNG', ix, iy, iw, ih);
            doc.setDrawColor(0); doc.setLineWidth(0.5); doc.rect(ix, iy, iw, ih);

            const rx = (ix + iw) - 70; const ry = (iy + ih) - 25;
            doc.setFontSize(10); doc.setFillColor(255, 255, 255); doc.rect(rx, ry, 70, 25, 'FD');
            doc.setFontSize(7);
            doc.text(`OBRA: ${projectData.projectName.substring(0,35)}`, rx+2, ry+4);
            doc.text(`DOMICILIO: ${projectData.address.substring(0,35)}`, rx+2, ry+8.5);
            doc.text(`INSTALADOR: ${projectData.installer.substring(0,35)}`, rx+2, ry+13);
            doc.text(`ESCALA: ${projectData.category}`, rx+2, ry+17.5);
            doc.text(`FECHA: ${projectData.date}`, rx+2, ry+22);

            doc.save(`plano_${projectData.projectName || 'electrico'}.pdf`);
        } catch (e) {
            console.error("PDF Error", e);
            stageRef.current.scale({ x: oldScale, y: oldScale }); stageRef.current.position(oldPos);
            elementsToHide.forEach(sel => stageRef.current.findOne(sel)?.show());
        }
    }, 100);
  };

  return (
    <div className="flex flex-col h-screen bg-slate-100">
      {/* HEADER BLINDADO: 
          1. h-16: Altura suficiente para botones grandes.
          2. relative: Contexto de posición.
      */}
      <div className="flex items-center justify-between px-3 bg-white border-b shadow-sm z-30 h-16 relative">
        
        {/* LADO IZQUIERDO: TÍTULO 
            z-20 y bg-white: Se asegura que esté POR ENCIMA de los botones si se cruzan.
            pr-6: Margen derecho interno para que el texto respire.
        */}
        <div className="flex items-center space-x-3 pr-6 bg-white z-20 h-full flex-shrink-0">
          <button onClick={() => navigate('/dashboard')} className="p-2 hover:bg-slate-100 rounded-full"><ArrowLeft className="w-5 h-5 text-slate-600"/></button>
          <h1 className="text-base font-bold text-slate-700 whitespace-nowrap">CAT III</h1>
        </div>
        
        {/* LADO DERECHO: BARRA DE HERRAMIENTAS
            absolute: Se posiciona libremente.
            inset-x-0: Ocupa todo el ancho.
            flex justify-end: Alinea botones a la derecha.
            pl-[140px]: Relleno izquierdo "duro" para que NUNCA pise al título.
            z-10: Capa inferior (se esconde detrás del título si falta espacio).
        */}
        <div className="absolute inset-x-0 h-full flex items-center justify-end pl-[140px] pr-2 z-10 pointer-events-none">
            {/* pointer-events-auto para que los botones funcionen */}
            <div className="pointer-events-auto overflow-x-auto no-scrollbar max-w-full flex justify-end">
                <PlannerSidebar tool={tool} setTool={setTool} onOpenReport={() => setShowMaterialModal(true)} onOpenProjectInfo={() => setShowProjectInfoModal(true)} />
            </div>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden relative">
        <PlannerToolbar 
             currentCircuitColor={currentCircuitColor} setCurrentCircuitColor={setCurrentCircuitColor} 
             currentPipeType={currentPipeType} setCurrentPipeType={setCurrentPipeType} 
             onDownloadPDF={handleDownloadPDF} onDeleteSelected={handleDeleteSelected} onClearAll={handleClearAll}
             onCalibrate={() => { setTool('calibrate'); alert("DIBUJA UNA LÍNEA sobre una medida conocida."); }}
             scaleText={`1m = ${Math.round(pixelsPerMeter)}px`}
         />

        <div className="flex-1 bg-slate-200 relative overflow-hidden cursor-crosshair">
          <Stage 
            width={window.innerWidth} height={window.innerHeight} 
            draggable={tool === 'select'} 
            ref={stageRef} scaleX={stageScale} scaleY={stageScale} x={stagePos.x} y={stagePos.y} 
            onMouseDown={handleMouseDown} onMouseMove={handleMouseMove} onMouseUp={handleMouseUp} onWheel={handleWheel}
            style={{ cursor: getCursorStyle() }}
          >
            <Layer>
              <Rect x={4} y={4} width={1000} height={700} fill="black" opacity={0.1} cornerRadius={2} blurRadius={10} name="paper-shadow" listening={false} />
              <Rect x={0} y={0} width={1000} height={700} fill="white" name="paper-bg" listening={false} />
              
              {renderGrid()}
              
              <Group>
                  <Group x={1000 - 250} y={700 - 105} name="rotulo-visual" listening={false}>
                     <Rect width={250} height={105} stroke="black" strokeWidth={1} fill="white"/>
                     <Text text="RÓTULO (Vista Previa)" x={5} y={5} fontSize={10} fill="gray"/>
                     <Text text={`Obra: ${projectData.projectName.substring(0,25)}`} x={10} y={23} fontSize={11} fill="black"/>
                     <Text text={`Dir: ${projectData.address.substring(0,25)}`} x={10} y={40} fontSize={11} fill="black"/>
                     <Text text={`Inst: ${projectData.installer.substring(0,25)}`} x={10} y={57} fontSize={11} fill="black"/>
                     <Text text={`Escala: ${projectData.category}`} x={10} y={74} fontSize={11} fill="black"/>
                     <Text text={`Fecha: ${projectData.date}`} x={10} y={91} fontSize={10} fill="black"/>
                  </Group>

                  {walls.map((w,i) => (
                    <Group key={w.id||i} draggable={tool === 'select'} 
                        onDragEnd={(e) => {
                            const x = e.target.x(); const y = e.target.y();
                            setWalls(ws => ws.map(item => item.id===w.id ? {...item, points: [item.points[0]+x, item.points[1]+y, item.points[2]+x, item.points[3]+y]} : item));
                            e.target.position({x:0, y:0});
                        }}>
                        <Line points={w.points} stroke={selectedId === w.id ? "#3b82f6" : "black"} strokeWidth={5} lineCap="round" onClick={(e) => { e.cancelBubble = true; if (tool === 'select') selectShape(w.id); }} />
                    </Group>
                  ))}
                  {currentWall && <Line points={currentWall} stroke="black" strokeWidth={5} opacity={0.5} />}
                  
                  {pipes.map((p,i) => (
                     <Group key={p.id||i} onClick={() => selectShape(p.id)}>
                       {p.type==='curved' ? 
                         <Path data={`M${p.points[0]},${p.points[1]} Q${(p.points[0]+p.points[2])/2},${(p.points[1]+p.points[3])/2 + 30} ${p.points[2]},${p.points[3]}`} stroke={selectedId===p.id ? "#3b82f6" : p.color} strokeWidth={2} dash={[5,5]}/> : 
                         <Line points={p.points} stroke={selectedId===p.id ? "#3b82f6" : p.color} strokeWidth={2} />
                       }
                     </Group>
                  ))}
                  {currentPipePreview && <Line points={currentPipePreview} stroke={currentCircuitColor} strokeWidth={2} dash={[2,2]} />}

                  {auxLines.map((l,i) => (
                     <Group key={l.id||i} draggable={tool === 'select'} 
                        onDragEnd={(e) => {
                            const x = e.target.x(); const y = e.target.y();
                            setAuxLines(as => as.map(item => item.id===l.id ? {...item, points: [item.points[0]+x, item.points[1]+y, item.points[2]+x, item.points[3]+y]} : item));
                            e.target.position({x:0, y:0});
                        }}>
                         <Line points={l.points} stroke={selectedId===l.id ? "#3b82f6" : "#000000"} strokeWidth={3} onClick={(e) => { e.cancelBubble = true; selectShape(l.id); }} />
                     </Group>
                  ))}
                  {currentAuxLine && <Line points={currentAuxLine} stroke="#000000" strokeWidth={3} opacity={0.7}/>}
                  
                  {calibrationLine && <Line points={calibrationLine} stroke="red" strokeWidth={2} dash={[5,5]} />}

                  {symbols.map(renderSymbol)}
                  {renderSelectionNodes()}
                  <Transformer ref={transformerRef} />
              </Group>
            </Layer>
          </Stage>
        </div>
      </div>
      <MaterialReportModal isOpen={showMaterialModal} onClose={() => setShowMaterialModal(false)} symbols={symbols} pipes={pipes} walls={walls} pixelsPerMeter={pixelsPerMeter} />
      <ProjectInfoModal isOpen={showProjectInfoModal} onClose={() => setShowProjectInfoModal(false)} onSave={setProjectData} initialData={projectData} />
    </div>
  );
}