import React from 'react';
import { 
  MousePointer2, Square, Zap, Lightbulb, ToggleLeft, 
  Box, Fan, Snowflake, FileText, Table, 
  Minus, ClipboardList, PenTool, LayoutTemplate, ArrowDownToLine,
  StopCircle, LampWallUp 
} from 'lucide-react';
import { Tool } from './PlannerToolbar';

interface PlannerSidebarProps {
  tool: Tool;
  setTool: (tool: Tool) => void;
  onOpenReport: () => void;
  onOpenProjectInfo: () => void;
}

export default function PlannerSidebar({ tool, setTool, onOpenReport, onOpenProjectInfo }: PlannerSidebarProps) {
  
  const tools: { id: Tool; icon: any; label: string }[] = [
    { id: 'select', icon: MousePointer2, label: 'Mover' },
    { id: 'wall', icon: Square, label: 'Pared' },
    { id: 'pipe', icon: PenTool, label: 'Caño' },
    { id: 'aux_line', icon: Minus, label: 'Auxiliar' },
    { id: 'text', icon: FileText, label: 'Texto' },
    { id: 'table', icon: Table, label: 'Tabla' },
  ];

  const symbols: { id: Tool; icon: any; label: string }[] = [
    { id: 'light', icon: Lightbulb, label: 'Boca' },
    { id: 'wall_light', icon: LampWallUp, label: 'Aplique' },
    { id: 'outlet', icon: Zap, label: 'Toma' },
    { id: 'switch', icon: ToggleLeft, label: 'Llave' },
    { id: 'cp', icon: StopCircle, label: 'CP/D' },
    { id: 'ac', icon: Snowflake, label: 'Aire' },
    { id: 'fan', icon: Fan, label: 'Vent.' },
    { id: 'board', icon: Box, label: 'T.Gral' },
    { id: 'tpu', icon: LayoutTemplate, label: 'TPU' },
    { id: 'ground', icon: ArrowDownToLine, label: 'PAT' },
  ];

  return (
    <div className="flex items-center space-x-2 overflow-x-auto py-1 no-scrollbar px-2">
      {/* GRUPO 1: HERRAMIENTAS */}
      <div className="flex space-x-1 border-r border-slate-200 pr-2">
        {tools.map((item) => (
          <button
            key={item.id}
            onClick={() => setTool(item.id)}
            // VOLVIMOS A p-2 y tamaños normales
            className={`flex flex-col items-center justify-center p-2 rounded-lg min-w-[3.5rem] transition-all ${
              tool === item.id 
                ? 'bg-blue-100 text-blue-700 ring-2 ring-blue-500 ring-offset-1 shadow-sm' 
                : 'text-slate-600 hover:bg-slate-50 hover:scale-105'
            }`}
            title={item.label}
          >
            <item.icon className="w-5 h-5 mb-1" />
            <span className="text-[10px] font-medium leading-tight">{item.label}</span>
          </button>
        ))}
      </div>

      {/* GRUPO 2: SÍMBOLOS */}
      <div className="flex space-x-1 border-r border-slate-200 pr-2">
        {symbols.map((item) => (
          <button
            key={item.id}
            onClick={() => setTool(item.id)}
            className={`flex flex-col items-center justify-center p-2 rounded-lg min-w-[3.5rem] transition-all ${
              tool === item.id 
                ? 'bg-blue-100 text-blue-700 ring-2 ring-blue-500 ring-offset-1 shadow-sm' 
                : 'text-slate-600 hover:bg-slate-50 hover:scale-105'
            }`}
            title={item.label}
          >
            <item.icon className="w-5 h-5 mb-1" />
            <span className="text-[10px] font-medium leading-tight">{item.label}</span>
          </button>
        ))}
      </div>

      {/* GRUPO 3: ACCIONES */}
      <div className="flex space-x-1 pl-1">
        <button onClick={onOpenProjectInfo} className="flex flex-col items-center justify-center p-2 rounded-lg min-w-[3.5rem] text-slate-600 hover:bg-purple-50 hover:text-purple-700 transition-all">
          <FileText className="w-5 h-5 mb-1" />
          <span className="text-[10px] font-medium leading-tight">Rótulo</span>
        </button>

        <button onClick={onOpenReport} className="flex flex-col items-center justify-center p-2 rounded-lg min-w-[3.5rem] text-slate-600 hover:bg-green-50 hover:text-green-700 transition-all">
          <ClipboardList className="w-5 h-5 mb-1" />
          <span className="text-[10px] font-medium leading-tight">Cómputo</span>
        </button>
      </div>
    </div>
  );
}