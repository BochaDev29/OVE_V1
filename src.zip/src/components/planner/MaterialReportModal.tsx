import React, { useMemo } from 'react';
import { X, Download, ClipboardList, FileSpreadsheet } from 'lucide-react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface MaterialReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  symbols: any[];
  pipes: any[];
  walls: any[];
  pixelsPerMeter: number;
}

export default function MaterialReportModal({ isOpen, onClose, symbols, pipes, walls, pixelsPerMeter }: MaterialReportModalProps) {
  if (!isOpen) return null;

  // --- CÁLCULOS MATEMÁTICOS ---
  const report = useMemo(() => {
    const counts: Record<string, number> = {};
    symbols.forEach(s => {
      if (s.type === 'text' || s.type === 'label' || s.type === 'table') return;
      const key = s.type === 'light' ? 'Bocas de Techo (Octogonales)' :
                  s.type === 'wall_light' ? 'Bocas de Pared (Apliques)' :
                  s.type === 'outlet' ? 'Cajas Rectangulares (Tomas)' :
                  s.type === 'switch' ? 'Cajas Rectangulares (Llaves)' :
                  s.type === 'ac' ? 'Tomas Aire Acondicionado' :
                  s.type === 'fan' ? 'Bocas Ventilador' :
                  s.type === 'board' ? 'Tablero General' :
                  s.type === 'tpu' ? 'Tablero TPU' :
                  s.type === 'cp' ? 'Cajas de Paso/Derivación' :
                  s.type === 'ground' ? 'Jabalina / PAT' : s.type;
      counts[key] = (counts[key] || 0) + 1;
    });

    let totalPipeMeters = 0;
    pipes.forEach(p => {
      const dx = p.points[2] - p.points[0];
      const dy = p.points[3] - p.points[1];
      const pixelLength = Math.sqrt(dx*dx + dy*dy);
      totalPipeMeters += pixelLength / pixelsPerMeter;
    });

    const verticalDrops = (counts['Cajas Rectangulares (Tomas)'] || 0) * 1.5 + 
                          (counts['Cajas Rectangulares (Llaves)'] || 0) * 1.5 +
                          (counts['Bocas de Pared (Apliques)'] || 0) * 0.5;
    const totalCableMeters = (totalPipeMeters + verticalDrops) * 3; 

    return { counts, totalPipeMeters, totalCableMeters };
  }, [symbols, pipes, pixelsPerMeter]);

  // --- EXPORTAR PDF ---
  const handleDownloadPDF = () => {
    try {
      const doc = new jsPDF();
      doc.setFontSize(18); doc.text("Cómputo de Materiales Estimado", 14, 22);
      doc.setFontSize(10); doc.text(`Fecha: ${new Date().toLocaleDateString()}`, 14, 30);
      
      const tableData = [
        ...Object.entries(report.counts).map(([name, count]) => [name, count, 'Unidades']),
        ['Cañería (Trazado Horizontal)', report.totalPipeMeters.toFixed(2), 'Metros'],
        ['Cable Unipolar 2.5mm (Estimado)', Math.ceil(report.totalCableMeters), 'Metros'],
      ];

      autoTable(doc, { startY: 40, head: [['Concepto', 'Cantidad', 'Unidad']], body: tableData, theme: 'grid' });
      doc.save('computo_materiales.pdf');
    } catch (error) { console.error(error); alert("Error al exportar PDF."); }
  };

  // --- EXPORTAR EXCEL (CSV) ---
  const handleDownloadExcel = () => {
    let csv = "Concepto,Cantidad,Unidad\n";
    
    // Items
    Object.entries(report.counts).forEach(([name, count]) => {
        csv += `"${name}",${count},Unidades\n`;
    });
    // Totales
    csv += `Cañería (Trazado Horizontal),${report.totalPipeMeters.toFixed(2)},Metros\n`;
    csv += `Cable Unipolar 2.5mm (Estimado),${Math.ceil(report.totalCableMeters)},Metros\n`;
    csv += `\n* Valores estimados según escala: 1m = ${Math.round(pixelsPerMeter)}px`;

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'computo_materiales.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl mx-4 flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center space-x-2 text-slate-700">
            <ClipboardList className="w-6 h-6" />
            <h2 className="text-xl font-bold">Listado de Materiales</h2>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-slate-100 rounded-full"><X className="w-6 h-6 text-slate-500" /></button>
        </div>

        <div className="p-6 overflow-y-auto">
          <div className="grid gap-6">
            <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
              <h3 className="font-semibold text-slate-700 mb-3 border-b pb-2">Cajas y Elementos</h3>
              <ul className="space-y-2">
                {Object.entries(report.counts).map(([name, count]) => (
                  <li key={name} className="flex justify-between text-sm"><span className="text-slate-600">{name}</span><span className="font-bold text-slate-900">{count} u.</span></li>
                ))}
              </ul>
            </div>
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
              <h3 className="font-semibold text-blue-800 mb-3 border-b border-blue-200 pb-2">Cañerías y Cables</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center"><span className="text-sm text-blue-700">Cañería (Horizontal)</span><span className="text-lg font-bold text-blue-900">{report.totalPipeMeters.toFixed(2)} m</span></div>
                <div className="flex justify-between items-center"><span className="text-sm text-blue-700">Cable 2.5mm (Estimado)</span><span className="text-lg font-bold text-blue-900">{Math.ceil(report.totalCableMeters)} m</span></div>
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 border-t bg-slate-50 flex justify-end space-x-3 rounded-b-lg">
          <button onClick={onClose} className="px-4 py-2 text-slate-600 hover:bg-slate-200 rounded-lg transition-colors font-medium">Cerrar</button>
          {/* BOTÓN EXCEL NUEVO */}
          <button onClick={handleDownloadExcel} className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white hover:bg-green-700 rounded-lg transition-colors font-medium shadow-sm">
            <FileSpreadsheet className="w-4 h-4" />
            <span>Excel</span>
          </button>
          <button onClick={handleDownloadPDF} className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white hover:bg-blue-700 rounded-lg transition-colors font-medium shadow-sm">
            <Download className="w-4 h-4" />
            <span>PDF</span>
          </button>
        </div>
      </div>
    </div>
  );
}