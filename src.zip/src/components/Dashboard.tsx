import { useState } from 'react';
import {
  Zap,
  Plus,
  LayoutDashboard,
  FolderOpen,
  Users,
  Calendar,
  Settings,
  LogOut,
  FileText,
  Clock,
  CheckCircle2,
  Building2,
  Home,
  Wrench,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Project {
  id: string;
  client_name: string;
  project_type: 'certificacion' | 'presupuesto';
  property_type: 'vivienda' | 'local';
  status: 'borrador' | 'en_ejecucion' | 'finalizado';
  surface_area: number;
  created_at: string;
}

interface DashboardProps {
  userEmail: string;
  onLogout: () => void;
  onNewProject: () => void;
  isDemoMode?: boolean;
}

const sampleProjects: Project[] = [
  {
    id: '1',
    client_name: 'Juan Pérez',
    project_type: 'certificacion',
    property_type: 'vivienda',
    status: 'en_ejecucion',
    surface_area: 85,
    created_at: '2025-11-15T10:30:00',
  },
  {
    id: '2',
    client_name: 'María González',
    project_type: 'presupuesto',
    property_type: 'local',
    status: 'borrador',
    surface_area: 120,
    created_at: '2025-11-18T14:20:00',
  },
  {
    id: '3',
    client_name: 'Carlos Rodríguez',
    project_type: 'certificacion',
    property_type: 'vivienda',
    status: 'finalizado',
    surface_area: 65,
    created_at: '2025-11-10T09:15:00',
  },
];

export default function Dashboard({
  userEmail,
  onLogout,
  onNewProject,
  isDemoMode = false,
}: DashboardProps) {
  const [activeSection, setActiveSection] = useState('dashboard');
  const navigate = useNavigate();

  const getStatusBadge = (status: Project['status']) => {
    const styles = {
      borrador: 'bg-slate-100 text-slate-700 border-slate-200',
      en_ejecucion: 'bg-blue-100 text-blue-700 border-blue-200',
      finalizado: 'bg-green-100 text-green-700 border-green-200',
    };

    const icons = {
      borrador: <FileText className="w-4 h-4" />,
      en_ejecucion: <Clock className="w-4 h-4" />,
      finalizado: <CheckCircle2 className="w-4 h-4" />,
    };

    const labels = {
      borrador: 'Borrador',
      en_ejecucion: 'En Ejecución',
      finalizado: 'Finalizado',
    };

    return (
      <span
        className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-sm font-medium border ${styles[status]}`}
      >
        {icons[status]}
        <span>{labels[status]}</span>
      </span>
    );
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-AR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <aside className="w-64 bg-slate-900 text-white flex flex-col">
        <div className="p-6 border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-600 p-2 rounded-lg">
              <Zap className="w-6 h-6" />
            </div>
            <div>
              <h2 className="font-bold text-lg">ERSEP</h2>
              <p className="text-xs text-slate-400">Oficina Virtual</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          <button
            onClick={() => setActiveSection('dashboard')}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
              activeSection === 'dashboard'
                ? 'bg-blue-600 text-white'
                : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <LayoutDashboard className="w-5 h-5" />
            <span className="font-medium">Panel Principal</span>
          </button>

          <button
            onClick={() => setActiveSection('projects')}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
              activeSection === 'projects'
                ? 'bg-blue-600 text-white'
                : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <FolderOpen className="w-5 h-5" />
            <span className="font-medium">Proyectos</span>
          </button>

          <button
            onClick={() => setActiveSection('clients')}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
              activeSection === 'clients'
                ? 'bg-blue-600 text-white'
                : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Users className="w-5 h-5" />
            <span className="font-medium">Clientes</span>
          </button>

          <button
            onClick={() => setActiveSection('calendar')}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
              activeSection === 'calendar'
                ? 'bg-blue-600 text-white'
                : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Calendar className="w-5 h-5" />
            <span className="font-medium">Agenda</span>
          </button>

          <button
            onClick={() => setActiveSection('settings')}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
              activeSection === 'settings'
                ? 'bg-blue-600 text-white'
                : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Settings className="w-5 h-5" />
            <span className="font-medium">Configuración</span>
          </button>
        </nav>

        <div className="p-4 border-t border-slate-800 space-y-3">
          {isDemoMode && (
            <div className="px-4 py-2 bg-amber-900 border border-amber-700 rounded-lg">
              <p className="text-xs font-medium text-amber-200">MODO DEMO</p>
              <p className="text-xs text-amber-300">Datos no persistentes</p>
            </div>
          )}
          <div className="px-4 py-3 bg-slate-800 rounded-lg">
            <p className="text-sm text-slate-400">Usuario</p>
            <p className="text-sm font-medium truncate">{userEmail}</p>
          </div>
          <button
            onClick={onLogout}
            className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-slate-300 hover:bg-slate-800 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span className="font-medium">Cerrar Sesión</span>
          </button>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto">
        <header className="bg-white border-b border-slate-200 px-8 py-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-slate-900">
                Panel Principal
              </h1>
              <p className="text-slate-600 mt-1">
                Bienvenido a tu oficina virtual
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate('/taller')}
                className="flex items-center space-x-2 px-6 py-3 bg-slate-600 text-white rounded-lg hover:bg-slate-700 transition-colors shadow-sm font-medium"
              >
                <Wrench className="w-5 h-5" />
                <span>ABRIR TALLER (BETA)</span>
              </button>
              <button
                onClick={onNewProject}
                className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-sm font-medium"
              >
                <Plus className="w-5 h-5" />
                <span>NUEVO PROYECTO</span>
              </button>
            </div>
          </div>
        </header>

        <div className="p-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
              <div className="flex items-center justify-between mb-4">
                <div className="bg-slate-100 p-3 rounded-lg">
                  <FileText className="w-6 h-6 text-slate-700" />
                </div>
                <span className="text-2xl font-bold text-slate-900">
                  {
                    sampleProjects.filter((p) => p.status === 'borrador')
                      .length
                  }
                </span>
              </div>
              <h3 className="text-slate-600 font-medium">Borradores</h3>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
              <div className="flex items-center justify-between mb-4">
                <div className="bg-blue-100 p-3 rounded-lg">
                  <Clock className="w-6 h-6 text-blue-600" />
                </div>
                <span className="text-2xl font-bold text-slate-900">
                  {
                    sampleProjects.filter((p) => p.status === 'en_ejecucion')
                      .length
                  }
                </span>
              </div>
              <h3 className="text-slate-600 font-medium">En Ejecución</h3>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
              <div className="flex items-center justify-between mb-4">
                <div className="bg-green-100 p-3 rounded-lg">
                  <CheckCircle2 className="w-6 h-6 text-green-600" />
                </div>
                <span className="text-2xl font-bold text-slate-900">
                  {
                    sampleProjects.filter((p) => p.status === 'finalizado')
                      .length
                  }
                </span>
              </div>
              <h3 className="text-slate-600 font-medium">Finalizados</h3>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-slate-200">
            <div className="px-6 py-4 border-b border-slate-200">
              <h2 className="text-lg font-semibold text-slate-900">
                Proyectos Recientes
              </h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">
                      Cliente
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">
                      Tipo
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">
                      Propiedad
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">
                      Superficie
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">
                      Estado
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">
                      Fecha
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {sampleProjects.map((project) => (
                    <tr
                      key={project.id}
                      className="hover:bg-slate-50 cursor-pointer transition-colors"
                    >
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-3">
                          <div className="bg-blue-100 p-2 rounded-lg">
                            <Users className="w-4 h-4 text-blue-600" />
                          </div>
                          <span className="font-medium text-slate-900">
                            {project.client_name}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600 capitalize">
                        {project.project_type}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-2">
                          {project.property_type === 'vivienda' ? (
                            <Home className="w-4 h-4 text-slate-400" />
                          ) : (
                            <Building2 className="w-4 h-4 text-slate-400" />
                          )}
                          <span className="text-sm text-slate-600 capitalize">
                            {project.property_type}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">
                        {project.surface_area} m²
                      </td>
                      <td className="px-6 py-4">
                        {getStatusBadge(project.status)}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">
                        {formatDate(project.created_at)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
